import { handleRequest } from './ssr-runtime.js';

function getPath(event) {
  return event.rawPath ?? event.requestContext?.http?.path ?? event.path ?? '/';
}

function getQueryString(event) {
  if (typeof event.rawQueryString === 'string' && event.rawQueryString.length > 0) {
    return `?${event.rawQueryString}`;
  }

  const params = event.queryStringParameters ?? {};
  const pairs = Object.entries(params)
    .filter((entry) => entry[1] !== undefined && entry[1] !== null)
    .map(([key, value]) => [key, String(value)]);

  if (pairs.length === 0) {
    return '';
  }

  return `?${new URLSearchParams(pairs).toString()}`;
}

export async function handler(event) {
  const url = `https://matcha.lambda${getPath(event)}${getQueryString(event)}`;
  const response = await handleRequest(url);
  return {
    statusCode: response.statusCode ?? 200,
    headers: response.headers ?? {},
    body: response.body ?? '',
    isBase64Encoded: false,
  };
}