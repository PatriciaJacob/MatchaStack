import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadServerSideProps, renderWithProps } from './entry-server.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const templatePath = path.resolve(__dirname, './ssr-template.html');
const ssrRoutes = ["/user-profile"];
const propsEndpoint = "/__matcha_props";
const staticPropsByRoute = {"/user-profile":{"builtAt":"2026-04-24T16:53:28.549Z"}};

function normalizePath(routePath) {
  return routePath === '/' ? routePath : routePath.replace(/\/$/, '');
}

function toRouteTarget(routeTarget) {
  const parsed = new URL(routeTarget, 'https://matcha.local');
  const pathname = normalizePath(parsed.pathname);
  return {
    pathname,
    target: `${pathname}${parsed.search}`,
  };
}

function escapeInlineJson(value) {
  return JSON.stringify(value).replace(/</g, '\\u003c');
}

function isSsrRoute(routeTarget) {
  return ssrRoutes.includes(toRouteTarget(routeTarget).pathname);
}

function loadCachedStaticProps(routePath) {
  return staticPropsByRoute[normalizePath(routePath)] ?? {};
}

export async function renderSsrPage(routeTarget) {
  const { pathname, target } = toRouteTarget(routeTarget);
  const [template, serverProps] = await Promise.all([
    readFile(templatePath, 'utf-8'),
    loadServerSideProps(target),
  ]);
  const staticProps = loadCachedStaticProps(pathname);
  const props = { ...staticProps, ...serverProps };
  const { html: appHtml } = renderWithProps(target, props);
  const propsScript = `<script>window.__INITIAL_PROPS__=${escapeInlineJson(props)}</script>`;
  const routesScript = "<script>window.__MATCHA_SSR_ROUTES__=[\"/user-profile\"]</script>";

  return template
    .replace('<!--ssr-outlet-->', appHtml)
    .replace('</head>', `${propsScript}${routesScript}</head>`);
}

export async function renderRouteProps(routeTarget) {
  const { pathname, target } = toRouteTarget(routeTarget);
  const staticProps = loadCachedStaticProps(pathname);
  const serverProps = await loadServerSideProps(target);
  return { ...staticProps, ...serverProps };
}

export async function handleRequest(input) {
  const requestUrl = typeof input === 'string'
    ? new URL(input, 'https://matcha.local')
    : input;
  const routeTarget = `${requestUrl.pathname}${requestUrl.search}`;

  if (requestUrl.pathname === propsEndpoint) {
    const routePath = requestUrl.searchParams.get('path') ?? '/';
    if (!routePath.startsWith('/')) {
      return {
        statusCode: 400,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'cache-control': 'no-store',
        },
        body: JSON.stringify({ error: 'Invalid path' }),
      };
    }

    if (!isSsrRoute(routePath)) {
      return {
        statusCode: 404,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'cache-control': 'no-store',
        },
        body: JSON.stringify({ error: 'Route is not SSR' }),
      };
    }

    const props = await renderRouteProps(routePath);
    return {
      statusCode: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      },
      body: JSON.stringify(props),
    };
  }

  if (isSsrRoute(routeTarget)) {
    const html = await renderSsrPage(routeTarget);
    return {
      statusCode: 200,
      headers: {
        'content-type': 'text/html; charset=utf-8',
        'cache-control': 'no-store',
      },
      body: html,
    };
  }

  return {
    statusCode: 404,
    headers: {
      'content-type': 'text/plain; charset=utf-8',
      'cache-control': 'no-store',
    },
    body: 'Not Found',
  };
}

export { isSsrRoute, propsEndpoint, ssrRoutes };